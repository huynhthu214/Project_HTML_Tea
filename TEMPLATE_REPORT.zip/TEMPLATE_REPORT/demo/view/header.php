<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffe House</title>
    <link rel="stylesheet" href="layout/css/style.css">
</head>

<body>
    <div class="containerfull padd20">
        <div class="container2 ">
            <div class="box3">154 cửa hàng khắp cả nước</div>
            <div class="box3">Hotline: 1800 6936</div>
            <div class="box3">Freeship từ 50.000 đ</div>
        </div>
    </div>