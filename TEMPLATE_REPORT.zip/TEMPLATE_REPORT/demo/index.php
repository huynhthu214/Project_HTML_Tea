<?php
include("view/header.php");
include("view/home.php");
include("view/footer.php");